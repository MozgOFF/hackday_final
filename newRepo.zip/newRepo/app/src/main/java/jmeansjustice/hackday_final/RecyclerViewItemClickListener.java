package jmeansjustice.hackday_final;

import android.view.View;

public interface RecyclerViewItemClickListener {
    public void onItemClicked(View v, int position, boolean isLongClick);

}
