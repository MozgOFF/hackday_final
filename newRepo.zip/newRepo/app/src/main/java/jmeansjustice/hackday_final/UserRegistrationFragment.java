package jmeansjustice.hackday_final;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

public class UserRegistrationFragment extends Fragment {
    private static final String TAG = "UserRegistrationFragment";

    private Button mButton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.user_registration_layout, container, false);

        mButton = view.findViewById(R.id.reg_but);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText((getActivity()), "Button is pressed", Toast.LENGTH_LONG).show();
            }
        });

        return view;
    }
}
